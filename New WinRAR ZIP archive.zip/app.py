# -*- coding: utf-8 -*-
import os
import json
import requests
import xmltodict
import mimetypes
import numbers
import xlrd
import xlsxwriter
from datetime import datetime,timedelta
from dateutil.parser import parse
from dateutil import parser
from string import whitespace
from collections import defaultdict
from flask_sqlalchemy import SQLAlchemy
import teradata as td
from werkzeug.utils import secure_filename
from werkzeug.debug import get_current_traceback

from flask import Flask, render_template, request, jsonify, redirect, \
                  url_for, session, flash, make_response, abort, send_from_directory

import oracle_connect
import config
import td_con


UPLOAD_FOLDER = 'D:/POC'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif','xls','xlsx','doc','docs'])


app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = "development-key"

@app.before_request
def userSession():
    try:
        if 'userName' not in session:
            session.permanent = False
            userName = config.TEST_USER_NAME
            bemsId = config.TEST_BEMSID
            emailId = "test@boeing.com"
            if config.WITH_WSSO:
                # get user info from WSSO
                userName = request.headers.get("boeingdisplayname")
                bemsId = request.headers.get("boeingbemsid")
                emailId = request.headers.get("mail")
            session['userName'] = userName
            session['bemsId'] = bemsId
            session['emailId'] = emailId
            print (session)
    except Exception as e:
        track= get_current_traceback(skip=1, show_hidden_frames=True,
            ignore_system_exceptions=False)
        track.log()
        abort(500)
        
@app.context_processor
def inject_user():
    return config.files


@app.route('/')
def app_home():
    return redirect(url_for('index'))

@app.route('/home')
def index():
    return render_template('home.html')

@app.route('/sales')
def sales():
    #field_to_display_sales = td_con.get_fields_to_display_sales()
    #file_name = oracle_connect.get_file_name_cust()
    #return render_template('sales.html',file_name=file_name)
    #return render_template('sales.html',field_to_display_sales=field_to_display_sales)
    return render_template('sales.html')

@app.route('/fieldToDisplaySales')
def field_to_display_sales():
    result = td_con.get_fields_to_display_sales()
    return jsonify(result)

@app.route('/fieldToDisplayProfit')
def field_to_display_profit():
    result = td_con.get_fields_to_display_profit()
    return jsonify(result)

@app.route('/profit')
def parts():
    #field_to_display_parts = td_con.get_fields_to_display_parts()
    #file_name = oracle_connect.get_file_name_parts()
    #return render_template('parts.html',file_name=file_name)
    return render_template('parts.html')

@app.route('/upload')
def upload():
    return render_template('upload.html')
	
@app.route('/downloadTemplate/<path:xls_name>')
def download_template(xls_name):
    """ return the template"""
    template_map = {"customer": "Customer_list.xlsx",
                    "parts": "Part_list.xlsx"}
    return send_from_directory('static', template_map.get(xls_name,"service_template.xlsx"), as_attachment=True)

@app.route('/adhocQuery/<string:data>', methods=['POST'])
def adhocQuery(data):
    if request.method == 'POST':
        
        result = dict()
        cust_list = None
        part_list=None
        user_name = config.USER_NAME
        try:
            field = request.form.get('field_row1',None)
            operator = request.form.get('operation_row1',None)
            value = request.form.get('value_row1',None)
            search_to = request.form.get('searchField',None)
            search_to_list = search_to.split(',')
            
            
            if data == 'sales':
                
                file_field = request.form.get('file_field1', None)
                print (file_field)
                if file_field:
                    file_name = request.form.get('custList_row1', None)
                    
                    
                    if file_name.lower() != 'select file name':
                        cust_list = oracle_connect.get_cust_list(file_name=file_name, user_name=user_name)
                        cust_list = "','".join(map(str, cust_list))
                if field:
                    field = config.SALES_FIELD[field]
                    
                searched_column_list = [config.SALES_FIELD.get(i) for i in search_to_list]
                searched_column = ','.join(searched_column_list)
    
                                                                                                                                                    
                if operator == 'Equal To':
                    operator = "="+value
                    query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_SIS"
                elif operator == 'Begins With':
                    print (searched_column)
                    if value:
                        operator = "LIKE'"+value+"%'"
                        print (value)
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_SIS"
                    elif cust_list:
                        operator="IN"
                        query = "Select TOP 1000 "+searched_column+" where CUST "+ operator+ " ('"+cust_list+ "') from MMBI_VIEWS_ADCUR.PN_SIS"   
                    '''elif cust_list and value:
                        operator = "LIKE'"+value+"%'"
                        #query1="SELECT TOP 100 SIS_NO,CUST,PART_NO,CREDIT_CONDITION,INVOICE_NO WHERE PART_NO LIKE'15%' FROM MMBI_VIEWS_ADCUR.PN_SIS"
                        query = "Select TOP 100 "+searched_column+" where "+field+" "+ operator+ " AND  CUST IN ('"+cust_list+ "') from MMBI_VIEWS_ADCUR.PN_SIS"
                     '''  
       
                elif operator == 'Contains':
    
                    if value:
                        operator = "LIKE'%"+value+"%'"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_SIS"
                    elif cust_list:
                        operator="IN"
                        query = "Select TOP 1000 "+searched_column+" where CUST"  + operator+ " ('"+cust_list+ "') from MMBI_VIEWS_ADCUR.PN_SIS"
                        
                elif operator == 'Ends With':
                    if value:
                        operator = "LIKE'%"+value+"'"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_SIS"
                    elif cust_list:
                        operator ="IN"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " ('"+cust_list+ "') from MMBI_VIEWS_ADCUR.PN_SIS"
                else:
                    operator ="IN"
                    query = "Select TOP 1000 "+searched_column+" where CUST "+ operator+ " ('"+cust_list+ "') from MMBI_VIEWS_ADCUR.PN_SIS"
                
            else: 
                data = 'parts'
                file_field = request.form.get('file_field1', None)
                if file_field:
                    file_name = request.form.get('custList_row1', None)
                    
                    if file_name.lower() != 'select file name':
                        part_list = oracle_connect.get_part_list(file_name=file_name, user_name=user_name)
                        part_list = "','".join(map(str,part_list))
                if field:
                    field = config.PARTS_FIELD[field]
                    print (field)
                searched_column_list = [config.PARTS_FIELD.get(i) for i in search_to_list]
                searched_column = ','.join(searched_column_list)
                if operator == 'Equal To':
                    operator = "="+value
                    query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_HEADER"
                elif operator == 'Begins With':
                    if part_list:
                        operatore = "IN"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " ('"+part_list+ "') from MMBI_VIEWS_ADCUR.PN_HEADER"
                    elif value:
                        operator = "LIKE'"+value+"%'"
                        #query1="SELECT TOP 100 SIS_NO,CUST,PART_NO,CREDIT_CONDITION,INVOICE_NO WHERE PART_NO LIKE'15%' FROM MMBI_VIEWS_ADCUR.PN_HEADER"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_HEADER"
                elif operator == 'Contains':
                    if value:
                        operator = "LIKE'%"+value+"%'"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_HEADER"
                    elif part_list:
                        operator = "IN"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ "('"+part_list+ "') from MMBI_VIEWS_ADCUR.PN_HEADER"
                elif operator == 'Ends With':
                    if value:
                        operator = "LIKE'%"+value+"'"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ " from MMBI_VIEWS_ADCUR.PN_HEADER"
                    elif part_list:
                        operator = "IN"
                        query = "Select TOP 1000 "+searched_column+" where "+field+" "+ operator+ "('"+part_list+ "') from MMBI_VIEWS_ADCUR.PN_HEADER"
                else:
                    operator = "IN"
                    query = "Select TOP 1000 "+searched_column+" where PART_NO "+ operator+ "('"+part_list+ "') from MMBI_VIEWS_ADCUR.PN_HEADER"
        
            #query = "Select "+search_to+" from MMBI_VIEWS_ADCUR.PN_SIS where "+field+"='"+value+"'"
            print (query)
    
            result['data'] = td_con.get_data_from_db(query, searched_column_list)
            result['message'] = 'success'
            return jsonify(result)
        except:
            #no search Criteria
            search_to = request.form['searchField']
            search_to_list = search_to.split(',')
            if data == 'sales':
                searched_column_list = [config.SALES_FIELD.get(i) for i in search_to_list]
                searched_column = ','.join(searched_column_list)
                query = "Select TOP 1000 "+searched_column+ " from MMBI_VIEWS_ADCUR.PN_SIS"
            else:
                data = 'parts'
                searched_column_list = [config.PARTS_FIELD.get(i) for i in search_to_list]
                searched_column = ','.join(searched_column_list)
                query = "Select TOP 1000 "+searched_column+" from MMBI_VIEWS_ADCUR.PN_HEADER"
            print (query)
            result['data'] = td_con.get_data_from_db(query, searched_column_list)
            result['message'] = 'success'
            return jsonify(result)

@app.route('/uploads/<filename>')
def uploaded_file(filename):

    return send_from_directory(app.config['UPLOAD_FOLDER'],filename)
	
@app.route('/UploadFile', methods=['POST'])
def UploadFile():
    finalData=[]
    result = {}
    files = request.files.get('file')
    file_type = request.form['file_name']
    file_name = files.filename
    filename, file_extension = os.path.splitext(file_name)
    if file_extension.lower() not in ['.xlsx','.xls']:
        message="Invalid file, file should be of type .xls, .xlsx"
        return emptyData,message
    workbook = xlrd.open_workbook(file_contents=files.read())
    sheet = workbook.sheet_by_index(0)
    
    for j in range(2, sheet.nrows):
        data = {}
        data_result=[]
        for i in range(0, sheet.ncols):
            cell_value_class = sheet.cell(1,i).value
            cell_value_id = sheet.cell(j,i).value
            data[cell_value_class] = cell_value_id
        data = {unicode(k).encode('utf-8'):unicode(v).encode('utf-8') for k,v in data.items() }
        finalData.append(data)
    oracle_connect.insert_excel_data_to_db(list_of_dicts=finalData, file_type=file_type)
    return "success"


if __name__ == '__main__':
    app.run(debug=True)