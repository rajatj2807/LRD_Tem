import teradata as td
import config

def get_con():
    udaExec = td.UdaExec(appName="Insourcing", version="1.0", logConsole=True)
    session = udaExec.connect(method="odbc", system="teraprd2.ca.boeing.com", username="A2475127", password="Safety1111")
    return session

def get_fields_to_display_sales():
    '''results = []
    session = get_con()
    rows = session.execute(config.DB_FIELD_TO_DISPLAY_SALES)
    row_data = rows.fetchall()
    for row in row_data:
        results.append(row[0].replace(' ',''))
    session.close()
    '''
    results = ['Month', 'Year', 'Basic', 'HRA', 'Personal Pay', 'CEA', 'PF', 'ITAX', 'PTAX', 'Medical']
    return results

def get_fields_to_display_parts():
    results = []
    session = get_con()
    rows = session.execute(config.DB_FIELD_TO_DISPLAY_PARTS)
    row_data = rows.fetchall()
    for row in row_data:
        results.append(row[0].replace(' ',''))
    session.close()
    return results

def get_fields_to_display_profit():
    results = ['Month', 'Year', 'Basic', 'HRA', 'Personal Pay', 'CEA', 'PF', 'ITAX', 'PTAX', 'Medical']
    return results


def get_data_from_db(query, searched_column_list):
    out=[]
    '''
    query = 'SELECT TOP 100 SIS_NO,CUST,PART_NO,CREDIT_CONDITION,INVOICE_NO, \
    INVOICE_STATUS_CD,METHOD_OF_SHIP,EXTENDED_SELLING_PRICE,PRICE,SIS_QTY FROM MMBI_VIEWS_ADCUR.PN_SIS'
    '''
    session = get_con()
    #column_map = config.SALES_FIELD
    rows = session.execute(query)
    results = rows.fetchall()
    for row in results:
        row_values = []
        for column in searched_column_list:
            row_values.append(str(row[column]))
        out.append(row_values)
    session.close()
    #print out
    return out

def insert_data(data, team_name):
    session = get_con()
    if team_name == "PARTS":
        #bulk insert
        query=''
    else:
        team_name == "SALES"
        #query ='("INSERT INTO ELABS_BGS_SSREPORT.SALES (SIS_NO, CUST, PART_NO, CREDIT_CONDITION,INVOICE_NO,INVOICE_STATUS_CD,METHOD_OF_SHIP,EXTENDED_SELLING_PRICE,PRICE,SIS_QTY) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",((11,12,13,14,15,16,17,18,19,20),(21,22,23,24,25,26,27,28,29,30)), batch=True)'
    out=[]
    rows = session.execute(query)
    results = rows.fetchall()
    session.close()
    return results


