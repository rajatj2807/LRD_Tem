import sys
from datetime import datetime
from cryptography.fernet import Fernet
import configparser
import cx_Oracle
import requests
import json
import requests
import base64
from collections import OrderedDict

from werkzeug.utils import secure_filename
from flask import abort, jsonify
from werkzeug.debug import get_current_traceback
import config


def get_db_pwd():
    """ read the dbconfig file and decrypt the db password"""
    dbconf = configparser.ConfigParser()
    inif = open(config.DB_CONFIG)
    dbconf.readfp(inif)
    key = dbconf.get("dbconf","key")
    pwd = dbconf.get("dbconf","pwd")
    cipher_suite = Fernet(key)
    return cipher_suite.decrypt(pwd)
	
    
def get_con():
    dsnStr = cx_Oracle.makedsn(config.DB_SERVER, config.DB_PORT, config.DB_NAME)
    con = cx_Oracle.connect(user=config.DB_USER, password=get_db_pwd(), dsn=dsnStr)
    return con 

def insert_excel_data_to_db(list_of_dicts=None, file_type=None):
    """ This function reads data from uploaded excel file and do a bulk insert
    into db using executemany() command"""
    con = get_con()
    cur = con.cursor()
    # get the file object and parse it
    # create a list of dictionaries as the input to executemany()
    if file_type == 'customer':
        insert_query = 'INSERT INTO SSP_CUSTOMER_LIST (USER_NAME, FILE_NAME, CUST_CODE) \
        values (:USER_NAME,:FILE_NAME,:CUST_CODE)'
    elif file_type == 'parts':
        insert_query = 'INSERT INTO SSP_PART_LIST (USER_NAME, FILE_NAME, PART_NO) \
        values (:USER_NAME,:FILE_NAME,:PART_NO)'
    cur.execute("ALTER SESSION SET NLS_DATE_FORMAT = 'MM/DD/YYYY'")
    cur.prepare(insert_query)
    cur.executemany(None, list_of_dicts)
    con.commit()
    
def get_file_name_cust():
    result = []
    # Returns unique file name from DB
    con = get_con()
    cur = con.cursor()
    select_query='select distinct(FILE_NAME) from SSP_CUSTOMER_LIST'
    cur.execute(select_query)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result

def get_file_name_parts():
    result = []
    # Returns unique file name from DB
    con = get_con()
    cur = con.cursor()
    select_query='select distinct(FILE_NAME) from SSP_PART_LIST'
    cur.execute(select_query)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result
    
def get_cust_list(file_name,user_name):
    result = []
    file_details = {'FILE_NAME' : file_name,
                    'USER_NAME' : user_name}
    # Returns customer list from DB
    con = get_con()
    cur = con.cursor()
    select_query="select CUST_CODE from SSP_CUSTOMER_LIST where FILE_NAME=:FILE_NAME and USER_NAME=:USER_NAME"
    cur.execute(select_query, file_details)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result
    
def get_part_list(file_name,user_name):
    result = []
    file_details = {'FILE_NAME' : file_name,
                    'USER_NAME' : user_name}
    # Returns customer list from DB
    con = get_con()
    cur = con.cursor()
    select_query="select PART_NO from SSP_PART_LIST where FILE_NAME=:FILE_NAME and USER_NAME=:USER_NAME"
    cur.execute(select_query, file_details)
    rowsData = cur.fetchall()
    for row in rowsData:
        result.append(row[0])
    cur.close()
    con.close()
    return result
    
    
